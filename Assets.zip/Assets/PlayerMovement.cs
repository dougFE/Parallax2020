﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    private float movementX;
    private float movementY;
    private Rigidbody2D rb;
    private SpriteRenderer sr;
    private Vector3 spawnLoc;

    //Easily tweakable gameplay values 
    public Vector2 speed = new Vector2(10, 10); //move speed
    public int health = 3; //player health
    public bool hasScroll = false; //start level with or without weapon

    //Weapon
    public GameObject scroll;
    public int pickupCooldown = 20;
    public int pickupTimer;

    //Flashing when hurt
    private int flashInt = 7; //Interval between flashes
    private int flashTime = 0; //Dynamic flash counter
    private int invulnTime = 60; //Time to flash

    // Start is called before the first frame update
    void Start()
    {

        //Disable physics rotation on collision
        rb = GetComponent<Rigidbody2D>();
        rb.freezeRotation = true;

        //Prep sprite renderer for flashing animation
        sr = GetComponent<SpriteRenderer>();
    }

    void Update()
    {

        //Restart if dead
        if (health <= 0)
        {
            SceneManager.LoadScene("Scene1");
        }


        spawnLoc = new Vector3(transform.position.x, transform.position.y, 0);

        //Throw scroll
        if (Input.GetMouseButtonDown(0) == true && hasScroll == true)
        {
            hasScroll = false;
            Instantiate(scroll, transform.position, transform.rotation);
            pickupTimer = 50;
        }

        //Look at mouse on screen
        Vector3 mouseScreenPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        Vector3 lookAt = mouseScreenPosition;

        float AngleRad = Mathf.Atan2(lookAt.y - this.transform.position.y, lookAt.x - this.transform.position.x);

        float AngleDeg = (180 / Mathf.PI) * AngleRad;

        this.transform.rotation = Quaternion.Euler(0, 0, AngleDeg - 90);

    }

    void FixedUpdate()
    {

        //Basic 2d movement script
        float inputX = Input.GetAxis("Horizontal");
        float inputY = Input.GetAxis("Vertical");

        Vector3 walking = new Vector3(speed.x * inputX, speed.y * inputY, 0);

        walking *= Time.deltaTime;

        transform.Translate(walking);

        //TODO
        //Make player child of empty that runs movement script
        //Would fix rotationally based movement and help spread out scripts 
        //Also fix the healthpacks


        //When time is added to flash timer by any source, this controls flashing by enabling and disabling the sprite renderer on player
        if (flashTime > 0)
        {
            flashTime -= 1;

            if (flashInt < 4 && flashInt != 0)
            {
                sr.enabled = false;
            }
            else
            {
                sr.enabled = true;
            }

            flashInt -= 1;
            if (flashInt <= 0)
            {
                flashInt = 7;
            }

        }

        if (pickupTimer > 0)
        {
            pickupTimer -= 1;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {

        //Take damage if hit by damage object, also makes player invuln while flashing
        if (collision.gameObject.tag == "Damage" && flashTime <= 0)
        {
            
            health -= 1;

            //Add time of flashing when hit
            flashTime = invulnTime;
            flashInt = 7;
        }

        //Pickup scroll if cooldown isn't in effect. Cooldown prevents instant pickups when scroll spawns inside player after a throw
        if (collision.gameObject.tag == "Scroll" && pickupTimer == 0)
        {
            GameObject other = collision.gameObject;
            hasScroll = true;
            Destroy(other);
            flashTime = 16;
            flashInt = 7;

        }

        //Colliding with enemy deals 1 dmg and instant kills enemy 
        if (collision.gameObject.tag == "Enemy")
        {
            health -= 1;

            //Add time of flashing when hit
            flashTime = invulnTime;
            flashInt = 7;

            Destroy(collision.gameObject);
        }

    }

}