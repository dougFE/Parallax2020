﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class scrollBehavior : MonoBehaviour
{

    public int bounceback = -1;
    public GameObject glowEffect;
    public Vector2 speed = new Vector2(10, 10);
    public int spawnTimer = 2;
    public int mult = 1;
    private Rigidbody2D rb;
    public GameObject player;

    public int lifeTimer = 60;

    // Start is called before the first frame update
    void Start()
    {
        Instantiate(glowEffect, transform);

        rb = GetComponent<Rigidbody2D>();
        rb.freezeRotation = true;
    }

    private void FixedUpdate()
    {
        lifeTimer -= 1;
    }

    // Update is called once per frame
    void Update()

    {
        Vector3 walking = new Vector3(0, speed.y * mult, 0);
        walking *= Time.deltaTime;
        transform.Translate(walking);
        if (bounceback > 0)
        {
            bounceback -= 1;
        }

        if (bounceback == 0 || lifeTimer <= 0)
        {
            speed *= 0;
        }
        if (spawnTimer > 0)
        {
            spawnTimer -= 1;
            mult = 10;
        }
        else
        {
            mult = 1;
        }


    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Wall" && speed.y > 0 && bounceback == -1)
        {
            bounceback = 5;
            speed *= -3;
        }

        if (collision.gameObject.tag == "Enemy")
        {
            GameObject other = collision.gameObject;
            Destroy(other);
            Destroy(this);
            player.GetComponent<PlayerMovement>().hasScroll = true;
        }
    }
}
