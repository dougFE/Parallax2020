﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretScript : MonoBehaviour
{

    public int fireinterval = 10;
    public GameObject bullet;
    public GameObject target;
    private float dist;

    private void Update()
    {
        dist = Vector3.Distance(transform.position, target.transform.position);

    }
    // Update is called once per frame
    void FixedUpdate()
    {
            if (fireinterval == 10 && dist < 35)
            {
                Instantiate(bullet, transform.position, transform.rotation);
            }
            if (fireinterval > 0)
            {
                fireinterval = fireinterval - 1;
            }
            if (fireinterval == 0)
            {
                fireinterval = 30;
            }
    }
}