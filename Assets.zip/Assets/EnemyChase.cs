﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyChase : MonoBehaviour
{

    public Transform mTarget;

    public float mSpeed = 3.0f;
    Vector3 mLookDirection;
    private Vector3 dist;

    const float EPSILON = 0.1f;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Vector3.Distance(transform.position, mTarget.transform.position) < 35)
        {
            mLookDirection = (mTarget.position - transform.position).normalized;

            if ((mTarget.position - transform.position).magnitude > EPSILON)

                transform.Translate(mLookDirection * Time.deltaTime * mSpeed);
        }

    }

}

